#ifndef INTERRUPT_H_
#define INTERRUPT_H_

void init_interrupt_1ms(void);
void init_interrupt_50us(void);
void interrupt_1ms(void);
void interrupt_50us(void);

#endif /* INTERRUPT_H_ */
