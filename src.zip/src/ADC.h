#ifndef ADC_H_
#define ADC_H_

void init_ADC(void);
short ad_convert(short an);

#endif /* ADC_H_ */
