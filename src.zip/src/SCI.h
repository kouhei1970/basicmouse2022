#ifndef SCI_H_
#define SCI_H_

void init_SCI(void);
void print_char_sci(unsigned char data);


#endif /* SCI_H_ */
