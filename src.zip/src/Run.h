#ifndef RUN_H_
#define RUN_H_

void straight(short length, short top_speed, short end_speed, short acc, char wall_control);
void turn(short angle);


#endif /* RUN_H_ */
